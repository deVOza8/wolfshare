from django.shortcuts import render

# Create your views here.
def developers(request):
    return render(request,'LoginRegister/developers.html')
