from django.apps import AppConfig


class DevelopersConfig(AppConfig):
    name = 'Developers'
