*How to run the application*


*Clone the repository git clone https://github.com/shreyanshs7/WallStreet18.git*


*Go to project directory*


*Build the docker image by running the command in your terminal*


`docker build -t wallstreet .`


*Then to run the server*


`docker run -it -p 8000:8000 wallstreet`


*Open your browser and go to http://localhost:8000*